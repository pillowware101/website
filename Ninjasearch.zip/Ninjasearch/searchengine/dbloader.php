<html>
		<head>
			<script src='searchengine.js' type='text/javascript'></script>
		</head>
		<body>
			<?php
				$query=$_GET["searchquery"];
				$pyout=`python3 searchresut.py`.' '.$query;
				

			?>
			
		</body>
</html>
