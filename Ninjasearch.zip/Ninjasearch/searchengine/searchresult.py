import re
import threading
from sys import argv, stdout
import concurrent.futures
import json

if len(argv)>=1:
    keyword=argv[1]
    keyword=list(keyword)
else:
    print('please enter a keyword')

keywordlist=[]
keyword=list(keyword)
indexes=None

def fromstart(l, keyword):
    global indexes
    global keywordlist
    indexes=len(l)/2
    if isinstance(l(list))==True:
        for x in range(indexes):
            for x in l:
                if x==keyword: 
                    keywordlist.append(x)
    return keywordlist

def fromending(l, keyword):
    global indexes
    global keywordlist
    indexes=len(l)/2
    counter=len(l)
    x=len(l)-1
    while counter>0:
        if l[x]==keyword:
            keywordlist.append(l[x])
    return keywordlist

with open('indexfile.json', 'r') as f:
    filecontent=json.loads(f.read())
    t1 = threading.Thread(target=fromstart, args=(keyword))
    t2 = threading.Thread(target=fromending, args=(keyword))
    t1.start()
    t2.start()
    t2.join()
