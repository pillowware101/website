package main

import "fmt"

func sum(num1, num2 int) int{
	var result int=num1+num2;
	return result;
}

func dict(name, key, value string) string{
	var name map[string]string;
	name=make(map[string]string);
	name[key]=value;
	return name;
}

func main(){
	const x float64=3.14159265358979323846264338327950;
	var y=sum(3, 4);
	fmt.Println(y);
	var z=dict(numbers, y, x);
	fmt.Println(z)
}