from urllib.request import urlopen
from bs4 import BeautifulSoup
import re
from lxml.html import parse
from sys import argv

linklist=[]
def gettext(url):
    t = lxml.html.parse(url)
    title=t.find(".//title").text
    content = urlopen(url)
    read_content = content.read()
    soup = BeautifulSoup(read_content,'html.parser')
    pAll = soup.find_all('p')
    h2All = soup.find_all('h2')
    text='text='+pAll+h2All
    title='title='+title
    with open('indexfile.json', 'a+') as f:
        if url not in str(f.read()):
            pass
            
pages = set()
path='/media/ishan/BABA/searchengine/db'
def getLinks(pageUrl):
    global pages
    html = urlopen('http://en.wikipedia.org'.format(pageUrl))
    bs = BeautifulSoup(html, 'html.parser')
    try:
        print(bs.h1.get_text())
        print(bs.find_all('p'))
    except AttributeError:
        print('This page is missing something! Continuing.')

    for link in bs.find_all('a', href=re.compile('^(/wiki/)')):
        if 'href' in link.attrs:
            if link.attrs['href'] not in pages:
#We have encountered a new page
                newPage = link.attrs['href']
                print('-'*20)
                print(newPage)
                pages.add(newPage)
                gettext(newPage)
                getLinks(newPage)

