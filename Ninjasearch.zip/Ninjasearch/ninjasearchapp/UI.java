import javax.swing.*;

class Window extends JFrame{
    JPanel pnl= new JPanel();
    ClassLoader ldr=this.getClass().getClassLoader();
    java.net.URL searchurl=ldr.getResource("search.png");
    ImageIcon search=new ImageIcon(searchurl);
    JLabel searchlbl=new JLabel("search query");
    //searchlbl.setToolTip("enter your search term in the field that is to the right of this label");
    searchlbl.setHorizontalTextPosition(JLabel.LEFT);
    public Window(){
        super("Swing Window");
        setSize(500, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        add(pnl);
        JButton searchBtn=new JButton(search);
        setVisible(true);
        pnl.add(searchBtn);
        pnl.add(searchlbl);
    }
    public static void main(String[] args){
        Window gui=new Window();
    }
}